from pydantic import BaseModel
from typing import Optional, Dict, Any, List

class BogieChecksheetBody(BaseModel):
    formNumber: str
    inspectionBy: str
    inspectionDate: str
    bogieChecksheet: Optional[Dict[str, Any]]
    bmbcChecksheet: Optional[Dict[str, Any]]
    bogieDetails: Optional[Dict[str, Any]]

class BogieChecksheetResponseData(BaseModel):
    formNumber: str
    inspectionBy: str
    inspectionDate: str
    status: str

class BogieChecksheetResponse(BaseModel):
    success: bool
    message: str
    data: BogieChecksheetResponseData

class WheelSpecificationItem(BaseModel):
    formNumber: str
    submittedBy: str
    submittedDate: str

class WheelSpecificationResponse(BaseModel):
    success: bool
    message: str
    data: List[WheelSpecificationItem]
