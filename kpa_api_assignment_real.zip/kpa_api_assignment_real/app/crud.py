from sqlalchemy.orm import Session
from . import models, schemas

def create_bogie_checksheet(db: Session, form: schemas.BogieChecksheetBody):
    db_form = models.BogieChecksheet(
        form_number=form.formNumber,
        inspection_by=form.inspectionBy,
        inspection_date=form.inspectionDate,
        status="Saved"
    )
    db.add(db_form)
    db.commit()
    db.refresh(db_form)
    return db_form

def get_wheel_specifications(db: Session, formNumber: str = None, submittedBy: str = None, submittedDate: str = None):
    query = db.query(models.WheelSpecification)
    if formNumber:
        query = query.filter(models.WheelSpecification.form_number == formNumber)
    if submittedBy:
        query = query.filter(models.WheelSpecification.submitted_by == submittedBy)
    if submittedDate:
        query = query.filter(models.WheelSpecification.submitted_date == submittedDate)
    return query.all()
