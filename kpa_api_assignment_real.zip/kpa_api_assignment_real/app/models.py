from sqlalchemy import Column, Integer, String
from .database import Base

class BogieChecksheet(Base):
    __tablename__ = "bogie_checksheet"

    id = Column(Integer, primary_key=True, index=True)
    form_number = Column(String, unique=True, index=True)
    inspection_by = Column(String)
    inspection_date = Column(String)
    status = Column(String)

class WheelSpecification(Base):
    __tablename__ = "wheel_specifications"

    id = Column(Integer, primary_key=True, index=True)
    form_number = Column(String, unique=True, index=True)
    submitted_by = Column(String)
    submitted_date = Column(String)
