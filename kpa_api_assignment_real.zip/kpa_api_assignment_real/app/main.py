from fastapi import FastAPI, Depends, Query
from sqlalchemy.orm import Session
from . import models, schemas, crud
from .database import engine, SessionLocal, Base

models.Base.metadata.create_all(bind=engine)

app = FastAPI()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/api/forms/bogie-checksheet", response_model=schemas.BogieChecksheetResponse)
def create_bogie_checksheet(form: schemas.BogieChecksheetBody, db: Session = Depends(get_db)):
    db_form = crud.create_bogie_checksheet(db, form)
    response_data = schemas.BogieChecksheetResponseData(
        formNumber=db_form.form_number,
        inspectionBy=db_form.inspection_by,
        inspectionDate=db_form.inspection_date,
        status=db_form.status
    )
    return {
        "success": True,
        "message": "Bogie checksheet submitted successfully.",
        "data": response_data
    }

@app.get("/api/forms/wheel-specifications", response_model=schemas.WheelSpecificationResponse)
def read_wheel_specifications(
    formNumber: str = Query(None),
    submittedBy: str = Query(None),
    submittedDate: str = Query(None),
    db: Session = Depends(get_db)
):
    specs = crud.get_wheel_specifications(db, formNumber, submittedBy, submittedDate)
    result = []
    for s in specs:
        result.append({
            "formNumber": s.form_number,
            "submittedBy": s.submitted_by,
            "submittedDate": s.submitted_date
        })
    return {
        "success": True,
        "message": "Filtered wheel specification forms fetched successfully.",
        "data": result
    }
