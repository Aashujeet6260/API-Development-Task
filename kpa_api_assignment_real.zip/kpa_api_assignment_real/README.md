# KPA API Assignment - Real APIs

## Tech Stack
- Python FastAPI
- PostgreSQL
- SQLAlchemy

## Setup Instructions

1. Create PostgreSQL DB: `kpa_db`
2. Copy `.env.example` to `.env` and add your credentials.
3. Install dependencies:
   ```
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```
4. Run the app:
   ```
   uvicorn app.main:app --reload
   ```

## APIs

- POST `/api/forms/bogie-checksheet` : Submit bogie checksheet form
- GET `/api/forms/wheel-specifications` : Get wheel specifications (with query filters)

## Testing

Test with Postman:
- URL: `http://127.0.0.1:8000/api/forms/...`
- Method: POST / GET
- Body: JSON per Swagger
